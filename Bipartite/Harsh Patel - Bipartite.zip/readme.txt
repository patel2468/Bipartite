Bipartite Run Instructions on stdlinux						Harsh Patel
															CSE2321 Zaccai

stdlinux
Compile: javac -cp ".:/class/software/common/components.jar" Bipartite.java
Run: java -cp ".:/class/software/common/components.jar" Bipartite TestFile.txt

Replace TestFile.txt with a correctly formatted text file.